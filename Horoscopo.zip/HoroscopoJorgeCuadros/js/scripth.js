document.addEventListener("DOMContentLoaded", function() {
    inicio()
})

function mostrarInformacion(id) {
    var xhr = new XMLHttpRequest()
    xhr.open("GET", "../db/data.xml", true)
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var xmlDoc = xhr.responseXML

            var signo = xmlDoc.getElementsByTagName("signo")[id - 1]
            var nombre = signo.getElementsByTagName("nombre")[0].childNodes[0].nodeValue
            var imagen = signo.getElementsByTagName("imagen")[0].childNodes[0].nodeValue
            var fechaInicio = signo.getElementsByTagName("fechaInicio")[0].childNodes[0].nodeValue
            var fechaFin = signo.getElementsByTagName("fechaFin")[0].childNodes[0].nodeValue
            var prediccion = signo.getElementsByTagName("prediccion")[0].childNodes[0].nodeValue
            var caracteristicas = signo.getElementsByTagName("caracteristicas")[0].childNodes[0].nodeValue

            var infoDiv = document.getElementById("informacion-ajax")
            infoDiv.innerHTML = ""
            
            var imgElement = document.createElement("img")
            imgElement.src = imagen
            imgElement.alt = nombre
            infoDiv.appendChild(imgElement)

            var titulo = document.createElement("h2")
            titulo.textContent = nombre
            infoDiv.appendChild(titulo)

            var fecha = document.createElement("p")
            fecha.textContent = fechaInicio + " - " + fechaFin
            infoDiv.appendChild(fecha)

            var h2_1 = document.createElement("h2")
            h2_1.textContent = "PREDICCIÓN DE HOY"
            infoDiv.appendChild(h2_1)

            var predict = document.createElement("p")
            predict.textContent = prediccion
            infoDiv.appendChild(predict)

            var charact = document.createElement("h2")
            charact.textContent = "CARACTERÍSTICAS DEL SIGNO"
            infoDiv.appendChild(charact)

            var info = document.createElement("p")
            info.textContent = caracteristicas
            infoDiv.appendChild(info)


        }   
    }
    xhr.send()
}

function mostrarInformacion2(id) {
    var xhr = new XMLHttpRequest()
    xhr.open('GET', '../db/data.xml', true)
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var xmlDoc = xhr.responseXML
            
            var animal = xmlDoc.getElementsByTagName("animal")[id - 1]
            var nombre = animal.getElementsByTagName("nombre")[0].childNodes[0].nodeValue
            var imagen = animal.getElementsByTagName("imagen")[0].childNodes[0].nodeValue
            var años = animal.getElementsByTagName("años")[0].childNodes[0].nodeValue
            var descripcion = animal.getElementsByTagName("descripcion")[0].childNodes[0].nodeValue

            var infoDiv = document.getElementById('informacion-ajax2')
            infoDiv.innerHTML = ""

            var imgElement = document.createElement("img")
            imgElement.src = imagen
            imgElement.alt = nombre
            infoDiv.appendChild(imgElement)

            var titulo = document.createElement("h2")
            titulo.textContent = nombre
            infoDiv.appendChild(titulo)

            var ciclo = document.createElement("p")
            ciclo.textContent = años
            infoDiv.appendChild(ciclo)

            var desc = document.createElement("p")
            desc.textContent = descripcion
            infoDiv.appendChild(desc)
        }
    }
    xhr.send()
}

function mostrarHoroscopos() {
    mostrarHoroscopo()
    mostrarHoroscopoChino()
}

function mostrarHoroscopo() {
    let fechaNacimiento = document.getElementById('fechaNacimiento').value
    if (!fechaNacimiento) return

    let fecha = new Date(fechaNacimiento)
    let dia = fecha.getDate()
    let mes = fecha.getMonth() + 1

    let zodiaco = obtenerSignoZodiacal(dia, mes)

    const resultado = document.getElementById("resultado1")
    resultado.innerHTML = zodiaco
}

function obtenerSignoZodiacal(dia, mes) {
    if ((mes === 3 && dia >= 21) || (mes === 4 && dia <= 19)) return "Aries";
    if ((mes === 4 && dia >= 20) || (mes === 5 && dia <= 20)) return "Tauro";
    if ((mes === 5 && dia >= 21) || (mes === 6 && dia <= 20)) return "Géminis";
    if ((mes === 6 && dia >= 21) || (mes === 7 && dia <= 22)) return "Cáncer";
    if ((mes === 7 && dia >= 23) || (mes === 8 && dia <= 22)) return "Leo";
    if ((mes === 8 && dia >= 23) || (mes === 9 && dia <= 22)) return "Virgo";
    if ((mes === 9 && dia >= 23) || (mes === 10 && dia <= 22)) return "Libra";
    if ((mes === 10 && dia >= 23) || (mes === 11 && dia <= 21)) return "Escorpio";
    if ((mes === 11 && dia >= 22) || (mes === 12 && dia <= 21)) return "Sagitario";
    if ((mes === 12 && dia >= 22) || (mes === 1 && dia <= 19)) return "Capricornio";
    if ((mes === 1 && dia >= 20) || (mes === 2 && dia <= 18)) return "Acuario";
    if ((mes === 2 && dia >= 19) || (mes === 3 && dia <= 20)) return "Piscis";
    return "";
}

function mostrarHoroscopoChino() {
    let fechaNacimiento = document.getElementById('fechaNacimiento').value
    if (!fechaNacimiento) return
    
    let fecha = new Date(fechaNacimiento)
    let anio = fecha.getFullYear()

    let animal = obtenerAnimalChino(anio)

    const resultado = document.getElementById("resultado2")
    resultado.innerHTML = animal
}

function obtenerAnimalChino(anio) {
    const animales = ["Rata", "Buey", "Tigre", "Conejo", "Dragón", "Serpiente", "Caballo", "Cabra", "Mono", "Gallo", "Perro", "Cerdo"];
    let indice = (anio - 1900) % 12;
    return animales[indice];
}

const inicio = () => {
    //---------- INICIO HOROSCOPO 1
    const div1 = document.createElement("div")
    div1.setAttribute("class", "container")

    const main1 = document.createElement("main")

    const h1 = document.createElement("h1")
    const texto1 = document.createTextNode("Horóscopo y signos del zodíaco")
    h1.appendChild(texto1)
    main1.appendChild(h1)
    //---------- INICIO TABLA 1
    const table1 = document.createElement("table")
    //---------- INICIO BUCLE 1
    const tr1 = document.createElement("tr")

    const td1 = document.createElement("td")

    const img1 = document.createElement("img")
    const desc1 = document.createElement("div")
    desc1.setAttribute("class", "descripcion")
    desc1.textContent = "20/01 - 18/02"
    img1.setAttribute("src", "db/img/ico-acuario.png")
    img1.setAttribute("alt", "Acuario")
    img1.setAttribute("onclick", "mostrarInformacion(11)")
    td1.appendChild(img1)
    td1.appendChild(desc1)

    tr1.appendChild(td1)

    const td2 = document.createElement("td")

    const img2 = document.createElement("img")
    const desc2 = document.createElement("div")
    desc2.setAttribute("class", "descripcion")
    desc2.textContent = "19/02 - 20/03"
    img2.setAttribute("src", "db/img/ico-piscis.png")
    img2.setAttribute("alt", "Piscis")
    img2.setAttribute("onclick", "mostrarInformacion(12)")
    td2.appendChild(img2)
    td2.appendChild(desc2)

    tr1.appendChild(td2)

    const td3 = document.createElement("td")

    const img3 = document.createElement("img")
    const desc3 = document.createElement("div")
    desc3.setAttribute("class", "descripcion")
    desc3.textContent = "21/03 - 19/04"
    img3.setAttribute("src", "db/img/ico-aries.png")
    img3.setAttribute("alt", "Aries")
    img3.setAttribute("onclick", "mostrarInformacion(1)")
    td3.appendChild(img3)
    td3.appendChild(desc3)

    tr1.appendChild(td3)

    table1.appendChild(tr1)
    //---------- FIN BUCLE 1
    //---------- INICIO BUCLE 2
    const tr2 = document.createElement("tr")

    const td4 = document.createElement("td")

    const img4 = document.createElement("img")
    const desc4 = document.createElement("div")
    desc4.setAttribute("class", "descripcion")
    desc4.textContent = "20/04 - 20/05"
    img4.setAttribute("src", "db/img/ico-tauro.png")
    img4.setAttribute("alt", "Tauro")
    img4.setAttribute("onclick", "mostrarInformacion(2)")
    td4.appendChild(img4)
    td4.appendChild(desc4)

    tr2.appendChild(td4)

    const td5 = document.createElement("td")

    const img5 = document.createElement("img")
    const desc5 = document.createElement("div")
    desc5.setAttribute("class", "descripcion")
    desc5.textContent = "21/05 - 20/06"
    img5.setAttribute("src", "db/img/ico-geminis.png")
    img5.setAttribute("alt", "Geminis")
    img5.setAttribute("onclick", "mostrarInformacion(3)")
    td5.appendChild(img5)
    td5.appendChild(desc5)

    tr2.appendChild(td5)

    const td6 = document.createElement("td")

    const img6 = document.createElement("img")
    const desc6 = document.createElement("div")
    desc6.setAttribute("class", "descripcion")
    desc6.textContent = "21/06 - 22/07"
    img6.setAttribute("src", "db/img/ico-cancer.png")
    img6.setAttribute("alt", "Cáncer")
    img6.setAttribute("onclick", "mostrarInformacion(4)")
    td6.appendChild(img6)
    td6.appendChild(desc6)

    tr2.appendChild(td6)

    table1.appendChild(tr2)
    //---------- FIN BUCLE 2
    //---------- INICIO BUCLE 3
    const tr3 = document.createElement("tr")

    const td7 = document.createElement("td")

    const img7 = document.createElement("img")
    const desc7 = document.createElement("div")
    desc7.setAttribute("class", "descripcion")
    desc7.textContent = "23/07 - 22/08"
    img7.setAttribute("src", "db/img/ico-leo.png")
    img7.setAttribute("alt", "Leo")
    img7.setAttribute("onclick", "mostrarInformacion(5)")
    td7.appendChild(img7)
    td7.appendChild(desc7)

    tr3.appendChild(td7)

    const td8 = document.createElement("td")

    const img8 = document.createElement("img")
    const desc8 = document.createElement("div")
    desc8.setAttribute("class", "descripcion")
    desc8.textContent = "23/08 - 22/09"
    img8.setAttribute("src", "db/img/ico-virgo.png")
    img8.setAttribute("alt", "Virgo")
    img8.setAttribute("onclick", "mostrarInformacion(6)")
    td8.appendChild(img8)
    td8.appendChild(desc8)

    tr3.appendChild(td8)

    const td9 = document.createElement("td")

    const img9 = document.createElement("img")
    const desc9 = document.createElement("div")
    desc9.setAttribute("class", "descripcion")
    desc9.textContent = "23/09 - 22/10"
    img9.setAttribute("src", "db/img/ico-libra.png")
    img9.setAttribute("alt", "Libra")
    img9.setAttribute("onclick", "mostrarInformacion(7)")
    td9.appendChild(img9)
    td9.appendChild(desc9)

    tr3.appendChild(td9)

    table1.appendChild(tr3)
    //---------- FIN BUCLE 3
    //---------- INICIO BUCLE 4
    const tr4 = document.createElement("tr")

    const td10 = document.createElement("td")

    const img10 = document.createElement("img")
    const desc10 = document.createElement("div")
    desc10.setAttribute("class", "descripcion")
    desc10.textContent = "23/10 - 21/11"
    img10.setAttribute("src", "db/img/ico-escorpio.png")
    img10.setAttribute("alt", "Escorpio")
    img10.setAttribute("onclick", "mostrarInformacion(8)")
    td10.appendChild(img10)
    td10.appendChild(desc10)

    tr4.appendChild(td10)

    const td11 = document.createElement("td")

    const img11 = document.createElement("img")
    const desc11 = document.createElement("div")
    desc11.setAttribute("class", "descripcion")
    desc11.textContent = "22/11 - 21/12"
    img11.setAttribute("src", "db/img/ico-sagitario.png")
    img11.setAttribute("alt", "Sagitario")
    img11.setAttribute("onclick", "mostrarInformacion(9)")
    td11.appendChild(img11)
    td11.appendChild(desc11)

    tr4.appendChild(td11)

    const td12 = document.createElement("td")

    const img12 = document.createElement("img")
    const desc12 = document.createElement("div")
    desc12.setAttribute("class", "descripcion")
    desc12.textContent = "22/12 - 19/01"
    img12.setAttribute("src", "db/img/ico-capricornio.png")
    img12.setAttribute("alt", "Capricornio")
    img12.setAttribute("onclick", "mostrarInformacion(10)")
    td12.appendChild(img12)
    td12.appendChild(desc12)

    tr4.appendChild(td12)

    table1.appendChild(tr4)
    //---------- FIN BUCLE 4
    main1.appendChild(table1)
    //---------- FIN TABLA 1
    div1.appendChild(main1)

    const aside1 = document.createElement("aside")

    const infoDiv1 = document.createElement("div")
    const textoMain1 = document.createTextNode("Haz clic en un signo para ver la información.")
    infoDiv1.setAttribute("id", "informacion-ajax")
    infoDiv1.setAttribute("class", "informacion")
    infoDiv1.appendChild(textoMain1)
    aside1.appendChild(infoDiv1)


    div1.appendChild(aside1)

    document.body.appendChild(div1)
    //---------- FIN HOROSCOPO 1
    //---------- INICIO FECHA DE NACIMIENTO
    const div2 = document.createElement("div")

    const h2_1 = document.createElement("h2")
    const texto2 = document.createTextNode("¿Cuál es mi signo del zodíaco? ¿Y mi horoscopo chino?")
    h2_1.appendChild(texto2)
    div2.appendChild(h2_1)

    const label = document.createElement("label")
    const texto3 = document.createTextNode("Introduce tu fecha de nacimiento:")
    label.setAttribute("for", "fechaNacimiento")
    label.appendChild(texto3)
    div2.appendChild(label)

    const input = document.createElement("input")
    input.setAttribute("type", "date")
    input.setAttribute("id", "fechaNacimiento")
    input.setAttribute("onchange", "mostrarHoroscopos()")
    div2.appendChild(input)
    //---------- INICIO RESULTADOS
    const div3 = document.createElement("div")

    const p1 = document.createElement("p")
    const p2 = document.createElement("p")
    p1.textContent = "Tu signo del zodíaco es:"
    p2.textContent = "Tu horóscopo chino es:"

    const strong1 = document.createElement("strong")
    const strong2 = document.createElement("strong")
    strong1.setAttribute("id", "resultado1")
    strong2.setAttribute("id", "resultado2")
    p1.appendChild(strong1)
    p2.appendChild(strong2)
    div3.appendChild(p1)
    div3.appendChild(p2)

    div2.appendChild(div3)
    //---------- FIN RESULTADOS
    document.body.appendChild(div2)
    //---------- FIN FECHA DE NACIMIENTO
    //---------- INICIO HOROSCOPO 2
    const div4 = document.createElement("div")
    div4.setAttribute("class", "container")

    const main2 = document.createElement("main")

    const h2_2 = document.createElement("h2")
    const texto4 = document.createTextNode("El horóscopo chino")
    h2_2.appendChild(texto4)
    main2.appendChild(h2_2)

    const table2 = document.createElement("table")

    //---------- INICIO BUCLE 1
    const tr5 = document.createElement("tr")

    const td13 = document.createElement("td")
    const img13 = document.createElement("img")
    img13.setAttribute("src", "db/img/ico-rata.png")
    img13.setAttribute("alt", "Rata")
    img13.setAttribute("onclick", "mostrarInformacion2(1)")
    td13.appendChild(img13)
    tr5.appendChild(td13)

    const td14 = document.createElement("td")
    const img14 = document.createElement("img")
    img14.setAttribute("src", "db/img/ico-buey.png")
    img14.setAttribute("alt", "Buey")
    img14.setAttribute("onclick", "mostrarInformacion2(2)")
    td14.appendChild(img14)
    tr5.appendChild(td14)

    const td15 = document.createElement("td")
    const img15 = document.createElement("img")
    img15.setAttribute("src", "db/img/ico-tigre.png")
    img15.setAttribute("alt", "Tigre")
    img15.setAttribute("onclick", "mostrarInformacion2(3)")
    td15.appendChild(img15)
    tr5.appendChild(td15)

    table2.appendChild(tr5)
    //---------- FIN BUCLE 1
    //---------- INICIO BUCLE 2
    const tr6 = document.createElement("tr")

    const td16 = document.createElement("td")
    const img16 = document.createElement("img")
    img16.setAttribute("src", "db/img/ico-conejo.png")
    img16.setAttribute("alt", "Conejo")
    img16.setAttribute("onclick", "mostrarInformacion2(4)")
    td16.appendChild(img16)
    tr6.appendChild(td16)

    const td17 = document.createElement("td")
    const img17 = document.createElement("img")
    img17.setAttribute("src", "db/img/ico-dragon.png")
    img17.setAttribute("alt", "Dragón")
    img17.setAttribute("onclick", "mostrarInformacion2(5)")
    td17.appendChild(img17)
    tr6.appendChild(td17)

    const td18 = document.createElement("td")
    const img18 = document.createElement("img")
    img18.setAttribute("src", "db/img/ico-serpiente.png")
    img18.setAttribute("alt", "Serpiente")
    img18.setAttribute("onclick", "mostrarInformacion2(6)")
    td18.appendChild(img18)
    tr6.appendChild(td18)

    table2.appendChild(tr6)
    //---------- FIN BUCLE 2
    //---------- INICIO BUCLE 3
    const tr7 = document.createElement("tr")

    const td19 = document.createElement("td")
    const img19 = document.createElement("img")
    img19.setAttribute("src", "db/img/ico-caballo.png")
    img19.setAttribute("alt", "Caballo")
    img19.setAttribute("onclick", "mostrarInformacion2(7)")
    td19.appendChild(img19)
    tr7.appendChild(td19)

    const td20 = document.createElement("td")
    const img20 = document.createElement("img")
    img20.setAttribute("src", "db/img/ico-cabra.png")
    img20.setAttribute("alt", "Cabra")
    img20.setAttribute("onclick", "mostrarInformacion2(8)")
    td20.appendChild(img20)
    tr7.appendChild(td20)

    const td21 = document.createElement("td")
    const img21 = document.createElement("img")
    img21.setAttribute("src", "db/img/ico-mono.png")
    img21.setAttribute("alt", "Mono")
    img21.setAttribute("onclick", "mostrarInformacion2(9)")
    td21.appendChild(img21)
    tr7.appendChild(td21)

    table2.appendChild(tr7)
    //---------- FIN BUCLE 3
    //---------- INICIO BUCLE 4
    const tr8 = document.createElement("tr")

    const td22 = document.createElement("td")
    const img22 = document.createElement("img")
    img22.setAttribute("src", "db/img/ico-gallo.png")
    img22.setAttribute("alt", "Gallo")
    img22.setAttribute("onclick", "mostrarInformacion2(10)")
    td22.appendChild(img22)
    tr8.appendChild(td22)

    const td23 = document.createElement("td")
    const img23 = document.createElement("img")
    img23.setAttribute("src", "db/img/ico-perro.png")
    img23.setAttribute("alt", "Perro")
    img23.setAttribute("onclick", "mostrarInformacion2(11)")
    td23.appendChild(img23)
    tr8.appendChild(td23)

    const td24 = document.createElement("td")
    const img24 = document.createElement("img")
    img24.setAttribute("src", "db/img/ico-cerdo.png")
    img24.setAttribute("alt", "Cerdo")
    img24.setAttribute("onclick", "mostrarInformacion2(12)")
    td24.appendChild(img24)
    tr8.appendChild(td24)

    table2.appendChild(tr8)
    //---------- FIN BUCLE 4

    main2.appendChild(table2)

    div4.appendChild(main2)

    const aside2 = document.createElement("aside")

    const infoDiv2 = document.createElement("div")
    const textoMain2 = document.createTextNode("Haz clic en un animal para una breve descripción.")
    infoDiv2.setAttribute("id", "informacion-ajax2")
    infoDiv2.setAttribute("class", "informacion")
    infoDiv2.appendChild(textoMain2)
    aside2.appendChild(infoDiv2)

    div4.appendChild(aside2)

    document.body.appendChild(div4)
    //---------- FIN HOROSCOPO 2
}