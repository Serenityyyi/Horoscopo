document.addEventListener("DOMContentLoaded", function() {
    inicio()
})

const inicio = () => {
    const h1 = document.createElement("h1")
    const texto = document.createTextNode("¿Quieres saber la predicción del horóscopo?")
    h1.style.color = "#555"
    h1.style.textAlign = "center"
    h1.style.fontFamily = "sans-serif"
    h1.appendChild(texto)
    document.body.appendChild(h1)

    const flex = document.createElement("div")
    const a1 = document.createElement("a")
    const a1texto = document.createTextNode("Sí")
    const a2 = document.createElement("a")
    const a2texto = document.createTextNode("No")

    flex.style.display = "flex"
    flex.style.flexDirection = "row"
    flex.style.justifyContent = "space-between"
    flex.style.maxWidth = "400px"
    flex.style.margin = "auto"
    flex.style.fontFamily = "sans-serif"
    flex.style.marginTop = "3em"
    flex.style.fontSize = "1.5em"
    a1.style.color = "#2d5"
    a2.style.color = "#d25"

    a1.setAttribute("href", "horoscopo.html")
    a2.setAttribute("href", "no.html")

    flex.appendChild(a1)
    flex.appendChild(a2)
    a1.appendChild(a1texto)
    a2.appendChild(a2texto)
    document.body.appendChild(flex)
}